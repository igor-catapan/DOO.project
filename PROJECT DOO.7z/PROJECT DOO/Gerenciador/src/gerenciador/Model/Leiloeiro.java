/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gerenciador.Model;

import gerenciador.Herancas.Pessoa;
import java.io.Serializable;

/**
 *
 * @author PICHAU
 */
public class Leiloeiro extends Pessoa   {

    public Leiloeiro(String nome) {
        super(nome);
    }

 
    
    
    
}
