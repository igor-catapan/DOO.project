/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gerenciador.Exceptions;

/**
 *
 * @author PICHAU
 */
public class PrecoInvalido extends Exception {

    public PrecoInvalido(String msg) {
        super(msg);
    }
}
